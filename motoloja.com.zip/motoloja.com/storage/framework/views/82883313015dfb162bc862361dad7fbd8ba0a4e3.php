
<?php $__env->startSection('conteudo'); ?>





 

<div class='container'>
    <div class='card bg-dark text-white'>

        <div id="login">
            <div class="caixa">
                <form method="POST" action="/usuario/editar" autocomplete="off">
                    <center>

                        <?php if(count($errors)): ?>

                            <div class="alert alert-danger">

                                <strong>Atenção aos seguintes erros!</strong>

                                <br />

                                <ul>

                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                    <li><?php echo e($error); ?></li>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </ul>

                            </div>

                        <?php endif; ?>

                        <?php if(Session::has('mensagem')): ?>
                            <div class="alert alert-success"><?php echo e(Session::get('mensagem')); ?></div>
                        <?php endif; ?>

                        <h1>EDITAR CREDENCIAIS</h1>

                        <input type="hidden" name='idClientes' value='<?php echo e(Auth::user()->idClientes); ?>'>

                        <div class="name  <?php echo e($errors->has('nome') ? 'has-error' : ''); ?>">
                            <input class="" type="text" name="nomeCompleto" placeholder="Nome Completo" value="<?php echo e(Auth::user()->nomeCompleto); ?>">
                        </div>
                        <div class="name  <?php echo e($errors->has('cpf') ? 'has-error' : ''); ?>">
                            <input class="" type="text" maxlength="11"  oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*?)\..*/g, '$1');" name="cpf" placeholder="CPF" value="<?php echo e(Auth::user()->cpf); ?>">
                        </div>
                        <div class="name  <?php echo e($errors->has('dataNascimento') ? 'has-error' : ''); ?>">
                            <input class="" type="date" name="dataNascimento" placeholder="Nascimento" value="<?php echo e(Auth::user()->dataNascimento); ?>">
                        </div>
                        <div class="email  <?php echo e($errors->has('email') ? 'has-error' : ''); ?>">
                            <input class="" type="email" name="email" placeholder="E-mail" value="<?php echo e(Auth::user()->email); ?>">
                        </div>
                        <br>

                        <div class="entrar">

                            <?php echo csrf_field(); ?>

                            <input type="submit" class='bg-white p-2 text-dark ' value="Editar">
                        </div>
                        <br>
                    </center>
                </form>
            </div>
        </div>

    </div>
</div>

    <br>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('website.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\motoloja.com\resources\views/website/usuarioeditar.blade.php ENDPATH**/ ?>