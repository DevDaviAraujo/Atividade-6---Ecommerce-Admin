
<?php $__env->startSection('conteudo'); ?>

<div>
    <center class='container'>
        <div class='card bg-dark text-white'> <br>
            <div class="caixa">
                    <form method="POST" action="/usuario/editar" autocomplete="off">
                        <center>

                            <h1>CONTATO</h1>

                            <div class="name">
                                <h5> Nome:</h5>
                                <input class="" type="text" <?php if(Auth::check()): ?> value="<?php echo e(Auth::user()->nomeCompleto); ?> " <?php endif; ?>>
                            </div>
                            <div class="name ">
                                <h5> E-mail:</h5>
                                <input class="" type="text" <?php if(Auth::check()): ?> value="<?php echo e(Auth::user()->email); ?>" <?php endif; ?>>
                            </div>
                            <div class="name ">
                                <h5> Mensagem:</h5>
                                <textarea name="" id="" cols="30" rows="10"></textarea>
                            </div>

                            

                            <div class="entrar">

                                
                                <input type="submit" class='bg-white p-2 text-dark ' value="Enviar">
                            </div>
                            <br>
                        </center>
                    </form>
                </div>
            </div>
        </div>
    </center>
    
</div>
<br>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('website.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\motoloja.com\resources\views/website/faleConosco.blade.php ENDPATH**/ ?>