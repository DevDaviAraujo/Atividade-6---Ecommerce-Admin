
<?php $__env->startSection('conteudo'); ?>

<br>

<center>
<form class='text-black' method="POST" action="/administrativo/categorias/salvar" autocomplete="off">
    
    <h1>CREDENCIAS</h1>

    <?php if(count($errors)): ?>

    <div class='container-fluid'>
        <div class="alert alert-danger">

        <strong>Atenção aos seguintes erros!</strong>

        <br />

        <ul>

            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <li><?php echo e($error); ?></li>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </ul>

    </div>
    </div>
    

    <?php endif; ?> 

    <?php if(Session::has('mensagem')): ?>
        <div class="alert alert-success"><?php echo e(Session::get('mensagem')); ?></div>
    <?php endif; ?> 
    

    <div class="name  <?php echo e($errors->has('nome') ? 'has-error' : ''); ?>">
        <input class="" type="text" name="nome" placeholder="Nome" <?php if($categoria != null): ?> value='<?php echo e($categoria->nome); ?>' <?php endif; ?> >
    </div>
    <div  class="name  <?php echo e($errors->has('url_amigavel') ? 'has-error' : ''); ?>">
        <input class="" type='text' name="url_amigavel" placeholder="Url amigável" <?php if($categoria != null): ?> value='<?php echo e($categoria->url_amigavel); ?>' <?php endif; ?> >
   </div>

    <br>
    <div class="entrar">
        <?php echo csrf_field(); ?>

        <input type='hidden' name='id' <?php if($categoria != null): ?> value="<?php echo e($categoria->id); ?> <?php endif; ?>">
        <input type="submit" class='bg-dark text-white ' value='Salvar'>
    </div>
</form>
</center>

<br>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('administrativo.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\motoloja.com\resources\views/administrativo/categorias/cadastro.blade.php ENDPATH**/ ?>