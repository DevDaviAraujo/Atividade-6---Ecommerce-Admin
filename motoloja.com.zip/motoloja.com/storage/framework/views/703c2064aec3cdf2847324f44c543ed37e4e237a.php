
<?php $__env->startSection('conteudo'); ?>

<br>

<center>
<form class='text-black' method="POST" action="/administrativo/clientes/salvar" autocomplete="off">
    
    <h1>CREDENCIAS</h1>

    <?php if(count($errors)): ?>

    <div class='container-fluid'>
        <div class="alert alert-danger">

        <strong>Atenção aos seguintes erros!</strong>

        <br />

        <ul>

            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <li><?php echo e($error); ?></li>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </ul>

    </div>
    </div>
    

    <?php endif; ?> 

    <?php if(Session::has('mensagem')): ?>
        <div class="alert alert-success"><?php echo e(Session::get('mensagem')); ?></div>
    <?php endif; ?> 
    

    <div class="name  <?php echo e($errors->has('nome') ? 'has-error' : ''); ?>">
        <input class="" type="text" name="nomeCompleto" placeholder="Nome Completo" <?php if($cliente != null): ?> <?php if(Request::url() === $cliente->idClientes): ?> value="<?php echo e(old('nomeCompleto')); ?>"  <?php else: ?> value="<?php echo e(old('nomeCompleto',$cliente->nomeCompleto)); ?>" <?php endif; ?> <?php endif; ?>>
    </div>
    <div class="name  <?php echo e($errors->has('CPF') ? 'has-error' : ''); ?>">
        <input cslass="" type="text" maxlength="11"
            oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*?)\..*/g, '$1');" name="cpf"
            placeholder="CPF" <?php if($cliente != null): ?> <?php if(Request::url() === $cliente->idClientes): ?> value="<?php echo e(old('cpf')); ?>" <?php else: ?> value="<?php echo e(old('cpf',$cliente->cpf)); ?>" <?php endif; ?> <?php endif; ?>>
    </div>
    <div class="name  <?php echo e($errors->has('dataNascimento') ? 'has-error' : ''); ?>">
        <input class="" type="date" name="dataNascimento" placeholder="Nascimento" <?php if($cliente != null): ?> <?php if(Request::url() === $cliente->idClientes): ?>  value="<?php echo e(old('dataNascimento')); ?>" <?php else: ?> value="<?php echo e(old('dataNascimento',$cliente->dataNascimento)); ?>" <?php endif; ?> <?php endif; ?>>
    </div>
    <div class="email  <?php echo e($errors->has('email') ? 'has-error' : ''); ?>">
        <input class="" type="email" name="email" placeholder="E-mail" <?php if($cliente != null): ?> <?php if(Request::url() === $cliente->idClientes): ?>  value="<?php echo e(old('email')); ?>"  <?php else: ?> value="<?php echo e(old('email',$cliente->email)); ?>" <?php endif; ?> <?php endif; ?>>
    </div>

    <?php if($cliente != null): ?> 
        <?php if(Request::url() === $cliente->idClientes): ?>
        <?php endif; ?>
    <?php else: ?>
    <div  class="senha  <?php echo e($errors->has('senha') ? 'has-error' : ''); ?>">
        <input class="" type='password' name="senha" placeholder="Senha">
   </div>
    <div class="senha  <?php echo e($errors->has('confirmeSenha') ? 'has-error' : ''); ?>">
        <input type="password" class="" name="confirmeSenha" placeholder="Confirme a sua senha">
    </div>
     <?php endif; ?>
    


    <br>
    <div class="entrar">
        <?php echo csrf_field(); ?>

        <input type='hidden' name='idClientes' <?php if($cliente != null): ?> value="<?php echo e($cliente->idClientes); ?> <?php endif; ?>">
        <input type="submit" class='bg-dark text-white ' value='Salvar'>
    </div>
</form>
</center>

<br>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('administrativo.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\motoloja.com\resources\views/administrativo/clientes/cadastro.blade.php ENDPATH**/ ?>