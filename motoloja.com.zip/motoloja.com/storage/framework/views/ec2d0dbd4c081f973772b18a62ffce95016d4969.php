
<?php $__env->startSection('conteudo'); ?>

<br>

<center>

<div class='text-black' >
    
        
        <h1>Produtos</h1>

        <?php if(count($errors)): ?>

        <div class='container-fluid'>
            <div class="alert alert-danger">

                <strong>Atenção aos seguintes erros!</strong>

                <br />

                <ul>

                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <li><?php echo e($error); ?></li>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </ul>

            </div>
        </div>
        <?php endif; ?>

        <?php if(isset($produto)): ?>

            <form action="/administrativo/produtos/imagem" method="post" enctype="multipart/form-data">
                <?php echo e(csrf_field()); ?>


                <input type="hidden" name='idProdutos' value="<?php echo e($produto->idProdutos); ?>">
                <input type="file" name="image" />
                <button type="submit">Enviar</button>
            </form>
            <br>


            <div class='container d-flex'>
                <?php $__currentLoopData = $imagens; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class='p-2'>
                    <?php if($value->imagemPrincipal == true): ?> <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAB4AAAAeCAYAAAA7MK6iAAAACXBIWXMAAAsTAAALEwEAmpwYAAABT0lEQVR4nO2Wv0rDUBTGP8FFySC+g85Orjo4WERH/yyOuuugb1CEvoY+hoKbj1DsYmrIOQHpWkH8JLVNr829aSy9QTAfnCXn3O+Xc3PIvUCtEmKCPQpeKegyQQNViSlQwUEIwirBHQP8XCX4gILPYexUB45xlHWc4LCSYSGxSEHb2Op2+mwmf/5iWCg4z2rHa86mrOla/ScSHadBhGUKIgs4YoilksMYmlvRMOB9CppUBDkDxXUOOo4rS30w9OqPoFTs5t9M8fCjC8UpiYVBrocVKt6cYEGPIVYzrxj7VLwYNffub6G4s5g+McYmBTcF3Y7gaXcbFDxa8rdF4JbD8IOK96ngtOa71pZrucGCyxLms4Xgogh84g0c49gNjrHtDZxgyw1OsO4RvFY0XIE3sOb/C/9c9LTV+LtgMU6qeYWUuJdNnFRzgVpPpFq14ElfJafwsLkGTHsAAAAASUVORK5CYII="> <?php endif; ?>
                    <button class='btn btn-primary'><a href="/administrativo/produtos/imagem/imagemPrincipal/<?php echo e($produto->idProdutos); ?>/<?php echo e($value->id); ?>"> Imagem Principal </a></button>
                    <form method='POST' action="/administrativo/produtos/imagem/deletar">
                        <input type="hidden" name='id' value='<?php echo e($value->id); ?>'>
                        <?php echo csrf_field(); ?>

                        <input type="submit" class='btn btn-danger' value='Excluir'>
                    </form>
                    <div class="">
                        <img class="" style='width: 21rem; height: 21rem;' src="<?php echo e($value->getImagem()); ?>" alt="<?php echo e($value->id); ?>">
                    </div>
                </div>
                    
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>        
            
            <br>

        <?php endif; ?>

    <form method="POST" action="/administrativo/produtos/salvar" autocomplete="off">

        <?php if(Session::has('mensagem')): ?>
            <div class="alert alert-success"><?php echo e(Session::get('mensagem')); ?></div>
        <?php endif; ?> 

        <div class="name  <?php echo e($errors->has('nome') ? 'has-error' : ''); ?>">
            <input class="" type="text" name="nome" placeholder="Nome" <?php if(isset($produto)): ?> value='<?php echo e($produto->nome); ?>' <?php endif; ?> >
        </div>
        <div  class="name  <?php echo e($errors->has('descricao') ? 'has-error' : ''); ?>">
            <textarea name="descricao" cols="30" rows="10"> <?php if(isset($produto)): ?> <?php echo e($produto->descricao); ?> <?php endif; ?></textarea>
        </div>
        <div class="name  <?php echo e($errors->has('preco') ? 'has-error' : ''); ?>">
            <input type="text" class="" name="preco" placeholder="Preço"  <?php if(isset($produto)): ?> value='<?php echo e($produto->preco); ?>' <?php endif; ?>>
        </div>
        <div class="name  <?php echo e($errors->has('preco') ? 'has-error' : ''); ?>">
            <select id='idCategoria' name='idCategoria'  <?php if(isset($produto)): ?> value='<?php echo e($produto->idCategoria); ?>' <?php endif; ?>>
                <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($value->id); ?>"><?php echo e($value->nome); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <br>
        <div class="name  <?php echo e($errors->has('estoque') ? 'has-error' : ''); ?>">
            <input type="number" class="" name="estoque" placeholder="Estoque"  <?php if(isset($produto)): ?> value='<?php echo e($produto->estoque); ?>' <?php endif; ?>>
        </div>

        <br>
        <div class="entrar">
            <?php echo csrf_field(); ?>

            <input type='hidden' name='idProdutos' <?php if(isset($produto)): ?> value="<?php echo e($produto->idProdutos); ?> " <?php endif; ?>>
            <input type="submit" class='bg-dark text-white ' value='Salvar'>
        </div>
    </form>
</div>

</center>

<br>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('administrativo.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\motoloja.com\resources\views/administrativo/produtos/cadastro.blade.php ENDPATH**/ ?>