
<?php $__env->startSection('conteudo'); ?>

<br> 

<table class="table">
  <thead>
    <tr>
      <th scope="col">id</th>
      <th scope="col">Nome Completo</th>
      <th scope="col">CPF</th>
      <th scope="col">E-mail</th>
      <th scope="col">Data de Nascimento</th>
      <th scope="col">Status</th>
      <th scope="col"></th>

    </tr>
  </thead>
  <?php if(isset($cliente)): ?> 
  <tbody>
    <tr>
      <th scope="row"><?php echo e($cliente->idClientes); ?></th>
      <td><?php echo e($cliente->nomeCompleto); ?></td>
      <td><?php echo e($cliente->cpf); ?></td>
      <td><?php echo e($cliente->email); ?></td>
      <td><?php echo e($cliente->dataNascimento); ?></td>
      <td><?php echo e($cliente->status); ?></td>
    <td>
    
        <a href="/administrativo/clientes/cadastro/<?php echo e($cliente->idClientes); ?>">
            <button  class='btn btn-success'>
            <img style=' width: 1rem; height: 1rem;' src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAYAAADgdz34AAAACXBIWXMAAAsTAAALEwEAmpwYAAAAnUlEQVR4nO3SsQnCUBRA0b+AhQSHsVEnUcRBTOkEFuJIuoHiBCKC/REhQohGJL4UQm73m3vfe/yUOlJKWOCICzbohR0GuVc2bQfOEeLxh8ghauq8JjKPkKuJ5JHyJ6vG0i/kTyapRfmyk//RWR4gw7pG3vyfl8EgXI4ZhqV3v7TJ75Nji2slkkWeZV9Me8MoRFoJnLArNpmGBzrSG+5BPu5S+5Q9QQAAAABJRU5ErkJggg==">
                Editar
            </button>
        </a>
    </td>
    <td>
    
        <form action="/administrativo/clientes/deletar" method='POST'>
            <input type="hidden" name='idClientes' value='<?php echo e($cliente->idClientes); ?>'>
            <?php echo csrf_field(); ?>

            <input type='submit' value='Excluir'  class='btn btn-danger bi bi-trash-fill'>            
        </form>
    </td>
    <?php endif; ?>  
    </tr>
  </tbody>
  
</table>

<br>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('administrativo.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\motoloja.com\resources\views/administrativo/clientes/detalhes.blade.php ENDPATH**/ ?>