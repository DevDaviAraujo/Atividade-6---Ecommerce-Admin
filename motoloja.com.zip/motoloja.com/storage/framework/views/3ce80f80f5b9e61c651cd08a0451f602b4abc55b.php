

<?php $__env->startSection('conteudo'); ?>

<br>


    <div class='card container align-items-center '>
        <div class="borda">
            <div class='container-fluid'> <br>
                <h1 class='text-center'>Quem somos?</h1>
                <center>
                <img src="https://rrmotos.com.br/wp-content/uploads/sites/24/2021/03/empresa3.jpg"
                     width="300px"
                     alt="">
                </center>
                <p>
                    A nossa empresa XPTO foi fundada no ano de 2000, em Sabará, com o intuito de facilitar <br>
                    a vida dos motoqueiros. A nossa missão é realizar uma plataforma rápida, prática e <br>
                    segura para atender as necessidades do nosso público alvo da melhor maneira possível, <br>
                    podendo navegar com grande facilidade por ela,para encontrar cada coisa de sua <br> 
                    necessidade específica e fazendo uma compra de forma facilitada.
                </p>
            </div> <br>

        </div>
    </div>
    
    <br> <br>
    <?php $__env->stopSection(); ?>


<?php echo $__env->make('website.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\motoloja.com\resources\views/website/sobrenos.blade.php ENDPATH**/ ?>