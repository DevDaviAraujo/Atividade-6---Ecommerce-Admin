
<?php $__env->startSection('conteudo'); ?>

<link rel="stylesheet"
      type="text/css"
      href="../CSS/home.css">

<br>
<div class='container'>

<?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <div class="card">
    
    <div class='container-fluid'>
    <a class='text-dark' href="/categoria/<?php echo e($value->url_amigavel); ?>?filtro">
      <h2 class='p-2'> <?php echo e($value->nome); ?> </h2>
    </a>  
      <div class='scroll'>
        <div class='row'>
          <?php $__currentLoopData = $value->produtos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class='col'>
            <a href="/produtos/<?php echo e($value2->idProdutos); ?>">
              <div class="cardShop card" style="width: 18rem;">
                <center>
                <img style="width: 17rem; height: 17rem;" class="card-img-top imagem"
                     src="<?php echo e($value2->imagemPrincipal()); ?>"
                     alt="Card image cap">
               </center>
                <div class="card-body">
                  <h5 class="card-title">R$ <?php echo e($value2->moedaReal($value2->preco)); ?> ou 3x de R$
                    <?php echo e($value2->moedaReal($value2->preco/3)); ?></h5>
                  <p class="card-text"><?php echo e($value2->nome); ?></p>
                  <form class='text-white' method='POST' action="/carrinho/adicionar">
                    <input type="hidden" name='id' value='<?php echo e($value2->idProdutos); ?>' >
                    <input type="hidden" value='1' name='quantidade' >
                    <?php echo csrf_field(); ?>

                    <input type='submit' class="btn btn-primary h-5" value='Adicionar ao Carrinho'>
                                    
                  </form>
                </div>
              </div> 
            </a> <br>
          </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div> 
      </div>
    </div>
     <br>
  </div> <br>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
 <br>
<br>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('website.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\motoloja.com\resources\views/website/home.blade.php ENDPATH**/ ?>