
<?php $__env->startSection('conteudo'); ?>
<br>

<br>
<div class='container'>


    <div class="card">



        <div class='container-fluid'>
            <br>

            <div class='container-fluid'>
                <div class='row'>

                <div class='col'>
                    <div id="carouselExampleControls" style='width: 21rem; height: 21rem;' class="carousel slide" data-ride="carousel">
                        <div class="carousel-inner">
                                <div class="carousel-item active">
                                    <img class="d-block" style='width: 21rem; height: 21rem;' src="<?php echo e($produto->imagemPrincipal()); ?>" alt="">
                                </div>
                                <?php $__currentLoopData = $produto->imagensAdicionais(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="carousel-item">
                                    <img class="d-block" style='width: 21rem; height: 21rem;'  src="<?php echo e($value->getImagem()); ?>" alt="">
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                
                               
                            </div>
                            <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">
                                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                                <span class="sr-only">Previous</span>
                            </a>
                            <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
                                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                                <span class="sr-only">Next</span>
                            </a>
                        </div>
                    
                </div>
                    <br>
                <div class='col'>
                    <div class='container'>
                        <h3><?php echo e($produto->nome); ?></h3> <br>
                        <h4><?php echo e($produto->descricao); ?></h4> <br>
                        <h3>R$ <?php echo e($produto->moedaReal($produto->preco)); ?> ou 3x de R$ <?php echo e($produto->moedaReal($produto->preco/3)); ?></h3> <br>
                        <form class='text-white' method='POST' action="/carrinho/adicionar">
                            <input type="hidden" name='id' value='<?php echo e($produto->idProdutos); ?>' >
                            <p class='h4 text-dark'>Quantidade:</p> 
                            <input class='input-group-text input-border-color-primary' type='number' name='quantidade' min='1' max='<?php echo e($produto->estoque); ?>' value='1' class="num">
                                

                            <?php echo csrf_field(); ?>

                            <input type='submit' class="btn btn-primary" value='Adicionar ao Carrinho'>
                        
                        </form>
                    </div>
                </div>
                    
                    
                    <br>

                </div>
            </div>

            <br> <br>

            <div class='container-fluid'>
                <h2> <b> Semelhantes </b> </h2>
                <div class='scroll'>
                    <div class='row'>

                        <?php $__currentLoopData = $produtosSemelhantes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class='col'>
                            <a href="/produtos/<?php echo e($value2->idProdutos); ?>">
                                <div class="cardShop card" style="width: 18rem;">
                                    
                                    <img style="width: 17rem; height: 17rem;" class="card-img-top imagem"
                                     src="<?php echo e($value2->imagemPrincipal()); ?>"
                                        alt="Card image cap">
                                    
                                    <div class="card-body">
                                        <h5 class="card-title">R$ <?php echo e($value2->moedaReal($value2->preco)); ?> ou 3x de R$
                                            <?php echo e($value2->moedaReal($value2->preco/3)); ?></h5>
                                        <p class="card-text"><?php echo e($value2->nome); ?></p>
                                        <a href="#" class="btn btn-primary"><h5>Adicionar ao Carrinho </h5> </a>
                                    </div>
                                </div>
                            </a>
                        </div>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </div>
                </div>
            </div> <br>
        </div>

        <br>


    </div>
</div>
</div>
</div> <br><br>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('website.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\motoloja.com\resources\views/website/produtos.blade.php ENDPATH**/ ?>